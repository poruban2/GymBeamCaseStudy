import os
import json
import logging
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict, Any

import boto3
import requests
from botocore.exceptions import ClientError

s3_client = boto3.client('s3')
secrets_manager_client = boto3.client('secretsmanager')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

@dataclass
class MunicipalLibrary:
    """Represents a municipal library with its details."""
    id: str
    name: str
    street: str
    postal_number: str
    city: str
    county: str
    country: str
    latitude: float
    longitude: float
    opening_hours: dict

def get_secret(secret_name: str) -> str:
    """Retrieves a secret from AWS Secrets Manager."""
    try:
        get_secret_value_response = secrets_manager_client.get_secret_value(
            SecretId=secret_name
        )
        return get_secret_value_response['SecretString']
    except ClientError as e:
        logger.error(f"Couldn't retrieve secret '{secret_name}': {e}")
        raise e

def fetch_library_data(url: str, api_token: str) -> List[Dict[str, Any]]:
    """Fetches library data from the Golemio API."""
    headers = {
        'X-Access-Token': api_token,
        'Content-Type': 'application/json'
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status() 
        data = response.json()
        
        features = data.get("features")
        if not features:
            logger.warning("API response contained no 'features'. Exiting gracefully.")
            return [] 
        return features

    except requests.RequestException as e:
        logger.error(f"Error fetching data from API: {e}")
        raise
    except json.JSONDecodeError:
        logger.error(f"Failed to decode JSON from API response. Response text: {response.text}")
        raise

def process_features(features: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Transforms raw API features into a list of library dictionaries."""
    libraries = []
    for entry in features:
        try:
            library = MunicipalLibrary(
                id=entry["properties"]["id"],
                name=entry["properties"]["name"],
                street=entry["properties"]["address"]["street_address"],
                postal_number=entry["properties"]["address"]["postal_code"],
                city=entry["properties"]["address"]["address_formatted"],
                county=entry["properties"]["district"],
                country=entry["properties"]["address"]["address_country"],
                latitude=entry["geometry"]["coordinates"][0],
                longitude=entry["geometry"]["coordinates"][1],
                opening_hours=entry["properties"]["opening_hours"]
            )
            libraries.append(asdict(library))
        except (KeyError, IndexError) as e:
            logger.warning(f"Skipping malformed record. Missing key: {e}. Record: {entry}")
            continue
    return libraries

def store_in_s3(bucket: str, data: str, content_type: str = 'application/json') -> str:
    """Uploads data to a specified S3 bucket."""
    date_folder = datetime.now().strftime("%Y-%m-%d")
    file_name = "golemio_municipal_libraries.json"
    s3_key = f"{date_folder}/{file_name}"

    try:
        s3_client.put_object(
            Bucket=bucket,
            Key=s3_key,
            Body=data,
            ContentType=content_type
        )
        logger.info(f"Successfully uploaded {s3_key} to {bucket}")
        return s3_key
    except ClientError as e:
        logger.error(f"Error uploading file to S3: {e}")
        raise

def lambda_handler(event, context):
    """
    Main Lambda handler to fetch library data from Golemio API,
    process it, and upload the result as a JSON file to S3.
    """

    s3_bucket_name = os.environ.get('S3_BUCKET_NAME')
    golemio_url = os.environ.get('GolemioAPIUrl')
    secret_name = "GolemioApiTokenSecret"

    if not all([s3_bucket_name, golemio_url]):
        error_message = "Required environment variables S3_BUCKET_NAME or GolemioAPIUrl are not set."
        logger.error(error_message)
        return {'statusCode': 500, 'body': json.dumps(error_message)}

    try:
        # 1. Fetch data
        secret = json.loads(get_secret(secret_name))
        api_token = secret.get("GolemioAPIToken")
        raw_features = fetch_library_data(golemio_url, api_token)

        if not raw_features:
            return {
                'statusCode': 200,
                'body': json.dumps('No library data found or returned from API. No file was created.')
            }

        # 2. Process data
        processed_libraries = process_features(raw_features)
        file_content = json.dumps(processed_libraries, ensure_ascii=False)

        # 3. Store data
        s3_key = store_in_s3(s3_bucket_name, file_content)

        return {
            'statusCode': 200,
            'body': json.dumps(f'Successfully uploaded data to s3://{s3_bucket_name}/{s3_key}')
        }

    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps(f'An unexpected error occurred. Check logs for details.')
        }
